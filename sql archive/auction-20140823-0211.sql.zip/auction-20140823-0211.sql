-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 23, 2014 at 02:11 AM
-- Server version: 5.5.38-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `auction`
--

-- --------------------------------------------------------

--
-- Table structure for table `auctions`
--

CREATE TABLE IF NOT EXISTS `auctions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `products` text COLLATE utf8_unicode_ci NOT NULL,
  `start` datetime NOT NULL,
  `status` enum('active','ended') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `enter_prod_time` int(10) NOT NULL,
  `after_bid_time` int(10) NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `auctions`
--

INSERT INTO `auctions` (`id`, `name`, `products`, `start`, `status`, `enter_prod_time`, `after_bid_time`, `description`) VALUES
(2, 'Red heart auction', '%5B%222%22%2C%2211%22%2C%2210%22%2C%2212%22%2C%229%22%2C%221%22%2C%223%22%2C%224%22%5D', '2014-08-23 23:12:00', 'active', 55, 60, 'The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex nymphs. Waltz, bad nymph, for quick jigs vex!\n\nFox nymphs grab quick-jived waltz. Brick quiz whangs jumpy veldt fox. Bright vixens jump; dozy fowl quack. Quick wafting zephyrs vex bold Jim. Quick zephyrs blow, vexing daft Jim.');

-- --------------------------------------------------------

--
-- Table structure for table `bids`
--

CREATE TABLE IF NOT EXISTS `bids` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bid` float(8,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `images` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=30 ;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `images`, `created_at`, `updated_at`) VALUES
(6, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/5Fa3JsMGbWiJ.jpg"}', '2014-08-15 19:33:22', '2014-08-15 19:33:22'),
(7, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/G0AeQScHJzf1.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/G0AeQScHJzf1_medium.jpg"}', '2014-08-15 19:36:40', '2014-08-15 19:36:40'),
(8, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/9uScWpCuygfa.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/9uScWpCuygfa_medium.jpg"}', '2014-08-15 19:37:42', '2014-08-15 19:37:42'),
(9, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/gtL30QpINyRi.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/gtL30QpINyRi_medium.jpg"}', '2014-08-15 19:38:36', '2014-08-15 19:38:36'),
(10, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/WFidUHGfnIb5.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/WFidUHGfnIb5_medium.jpg"}', '2014-08-15 19:39:16', '2014-08-15 19:39:16'),
(11, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/Q3p2MnajsTgY.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/Q3p2MnajsTgY_medium.jpg"}', '2014-08-15 19:41:02', '2014-08-15 19:41:02'),
(12, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/Htnn4s11SRMP.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/Htnn4s11SRMP_medium.jpg"}', '2014-08-15 19:41:37', '2014-08-15 19:41:37'),
(13, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/HgfMMlpaw8yF.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/HgfMMlpaw8yF_medium.jpg"}', '2014-08-15 19:42:24', '2014-08-15 19:42:24'),
(14, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/KUSj8UkDoq6x.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/KUSj8UkDoq6x_medium.jpg"}', '2014-08-15 19:42:56', '2014-08-15 19:42:56'),
(15, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/44MWrSmlRtaq.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/44MWrSmlRtaq_medium.jpg"}', '2014-08-22 19:56:23', '2014-08-22 19:56:23'),
(16, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/q85hJkTBk2gt.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/q85hJkTBk2gt_medium.jpg"}', '2014-08-22 19:58:22', '2014-08-22 19:58:22'),
(17, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/5jA3r8AfrDtk.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/5jA3r8AfrDtk_medium.jpg"}', '2014-08-22 19:59:46', '2014-08-22 19:59:46'),
(18, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/39hGECpg3k6z.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/39hGECpg3k6z_medium.jpg"}', '2014-08-22 20:00:48', '2014-08-22 20:00:48'),
(19, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/JQurcvmnI7XS.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/JQurcvmnI7XS_medium.jpg"}', '2014-08-22 20:02:17', '2014-08-22 20:02:17'),
(20, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/3jvmH8QeaEAq.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/3jvmH8QeaEAq_medium.jpg"}', '2014-08-22 20:03:38', '2014-08-22 20:03:38'),
(21, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/2rpud95ItFR2.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/2rpud95ItFR2_medium.jpg"}', '2014-08-22 20:05:08', '2014-08-22 20:05:08'),
(22, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/RCgsXzeWGu0S.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/RCgsXzeWGu0S_medium.jpg"}', '2014-08-22 20:06:58', '2014-08-22 20:06:58'),
(23, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/5vzjjHnNVZxC.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/5vzjjHnNVZxC_medium.jpg"}', '2014-08-22 20:08:38', '2014-08-22 20:08:38'),
(24, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/dtZcT1xPGkfu.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/dtZcT1xPGkfu_medium.jpg"}', '2014-08-22 20:10:07', '2014-08-22 20:10:07'),
(25, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/ewHECLNzIg51.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/ewHECLNzIg51_medium.jpg"}', '2014-08-22 20:11:29', '2014-08-22 20:11:29'),
(26, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/sQktxOjcvdXe.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/sQktxOjcvdXe_medium.jpg"}', '2014-08-22 20:12:35', '2014-08-22 20:12:35'),
(27, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/F872AbMDGDNa.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/F872AbMDGDNa_medium.jpg"}', '2014-08-22 20:13:13', '2014-08-22 20:13:13'),
(28, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/MrSFSjyELaO9.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/MrSFSjyELaO9_medium.jpg"}', '2014-08-22 20:14:02', '2014-08-22 20:14:02'),
(29, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/CeX05Lv9x3OE.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/CeX05Lv9x3OE_medium.jpg"}', '2014-08-22 20:15:04', '2014-08-22 20:15:04');

-- --------------------------------------------------------

--
-- Table structure for table `metas`
--

CREATE TABLE IF NOT EXISTS `metas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `parent` enum('product','auction') COLLATE utf8_unicode_ci NOT NULL,
  `meta_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `meta_value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_08_11_000303_create_auctions_table', 1),
('2014_08_11_000602_create_bids_table', 1),
('2014_08_11_001015_create_products_table', 1),
('2014_08_11_001210_create_users_table', 1),
('2014_08_15_174338_create_images_table', 2),
('2014_08_23_020330_create_metas', 3);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('simple','auction') COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('draft','publish','hidden') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `lang` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` float(8,2) NOT NULL,
  `sale_price` float(8,2) NOT NULL,
  `opening_bid` float(8,2) NOT NULL,
  `auction_id` int(10) NOT NULL,
  `image_id` int(10) NOT NULL,
  `parent_id` int(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=28 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `type`, `status`, `lang`, `price`, `sale_price`, `opening_bid`, `auction_id`, `image_id`, `parent_id`, `created_at`, `updated_at`) VALUES
(1, 'Black Luxury Watch', 'Luxury Men Watch Black Steel wrist Watch Sport Styles top brand Men', 'auction', 'publish', '', 300.00, 0.00, 100.00, 2, 7, 0, '2014-08-14 20:46:00', '2014-08-22 20:17:18'),
(2, 'Youyoupifa', 'Youyoupifa Fashion Luxury Imitationold Quartz Wrist Watch', 'auction', 'publish', '', 570.00, 0.00, 199.00, 2, 8, 0, '2014-08-14 21:58:25', '2014-08-22 20:17:25'),
(3, 'Bossman Watch', 'Vantasy Men’s Luxury Gold Plated Stainless Steel Hand Wind Skeleton Analog Mechanical Black Leather Wrist Watch', 'auction', 'publish', '', 1300.00, 0.00, 1000.00, 2, 9, 0, '2014-08-15 12:47:54', '2014-08-22 20:17:30'),
(4, 'Oblong', 'Mens Luxury Oblong Skeleton Automatic Mechanical Black Leather Wrist Watch Cool', 'auction', 'publish', '', 1050.00, 0.00, 2300.00, 2, 10, 0, '2014-08-15 12:49:56', '2014-08-22 20:17:37'),
(9, 'Wind', 'Vantasy Roman Men’s Luxury Stainless Steel White Dial Skeleton Analog Hand Wind Mechanical Black Leather Wrist Watch – Wind', 'auction', 'publish', '', 1450.00, 0.00, 270.00, 2, 11, 0, '2014-08-15 19:40:26', '2014-08-22 20:17:48'),
(10, 'The Aquarium', 'Swiss watch company Angular Momentum represent its new model called “The Aquarium.” Aquarium shows a popular in Far East fish – Koi – in a muddy pond. It’s engraved in very high relief 925 silver, purple gold and Ruthenium treated surface. The eye of a koi made out from a diamond and the ground is done in black Ishime Urushi natural lacquer. The watch case is in Staybrite steel with polished and satin finished surfaces measuring 43mm wide by 16mm thick. The time is shown by single disc that spins behind the koi. These extremely beautiful luxury watches will be availiable in limited edition soon.', 'auction', 'publish', '', 1250.00, 0.00, 500.00, 2, 12, 0, '2014-08-15 19:41:33', '2014-08-22 20:17:54'),
(11, 'Key of Time', 'The “Key of Time” is impressive novelty piece from Hublot’s 2011 Masterpiece Collection. The name comes from the watch’s time-travelling ability, through 3 speed settings. For instance, you’re in a boring meeting and you can speed up the time or if it’s happy hour, you can slow it down. Of course this is just for fun, with the ingenious engineers also giving this watch the ability to return to the correct time, though its “mechanical memory”.', 'auction', 'publish', '', 1890.00, 0.00, 450.00, 2, 13, 0, '2014-08-15 19:42:16', '2014-08-22 20:18:00'),
(12, 'Opus Eleven', 'The Opus Eleven Watch is part of a numbered series of collaborative timepieces, which have gathered some of the most talented watchmakers to create for each one. This remarkable piece took over 14,400 hours to engineer alone. Using an complex system of gears and disks, the dial ‘explodes’ then reforms to display the time.', 'auction', 'publish', '', 2000.00, 0.00, 650.00, 2, 14, 0, '2014-08-15 19:42:51', '2014-08-22 20:18:11'),
(13, 'Central Tourbillon Co-Axial Platinum', 'Central Tourbillon Co-Axial Platinum luxury watch by Omega is a limited edition timepiece.\r\n\r\nSwiss watchmaker Omega offers several luxury watches.\r\n', 'simple', 'publish', '', 0.00, 0.00, 0.00, 0, 15, 0, '2014-08-22 19:56:13', '2014-08-22 19:56:23'),
(14, 'New 7727 Classique Chronométrie 10Hz Luxury Watch', 'The Classique Chronométrie 7727, packed with new discoveries and technological inventions, is a prime example as the achievement of several years of research into high frequency, magnetism and new materials.\r\n\r\nWith the patent of November 7, 2010 protecting the magnetic pivot, Breguet has set a new milestone in watchmaking history. The magnetic field crossing through the balancestaff keeps the balance stable.\r\n\r\n- See more at: http://www.thelifeofluxury.com/new-7727-classique-chronometrie-10hz-luxury-watch-by-breguet/#sthash.Dg8vAtpo.dpuf', 'simple', 'publish', '', 0.00, 0.00, 0.00, 0, 16, 0, '2014-08-22 19:58:12', '2014-08-22 19:58:22'),
(15, 'Kobe Bryant’s Nubeo Black Mamba Luxury Watch', 'Nubeo has created a timepiece inspired of a famous NBA basketball player named as Kobe Bryant who is also known as the Black Mamba. Kobe Bryant and the Lakers are on their way to the NBA finals and one way to celebrate it is wearing this Nubeo Kobe Bryan Black Mamba Luxury Watch.', 'simple', 'publish', '', 0.00, 0.00, 0.00, 0, 17, 0, '2014-08-22 19:59:39', '2014-08-22 19:59:46'),
(16, 'Devon Works Tread 1 Watch', 'The Devon Works Tread 1 Watch is arguably the most cutting edge amongst this entire group, a timepiece of striking visuals and technology.  The Tread 1 Watch features four internal 2-micron thin belts that spin within the case to display the time.  It’s powered by a lithium polymer rechargeable cell that is charged by wireless induction.  This electric system runs the belts that are kept in tune with an optical technology.  Add that all up, and you have one of the most technically advanced, visually stunning watches ever made.  The Devon Works Tread 1 Watch was designed by a California aerospace company, a group that is quite comfortable with fitting square pegs through round holes.  This watch is a prime example of their technical prowess - See more at: http://www.thecoolist.com/future-watches-10-examples-of-engineering-magnificence/#sthash.lirmZKva.dpuf', 'simple', 'publish', '', 0.00, 0.00, 0.00, 0, 18, 0, '2014-08-22 20:00:39', '2014-08-22 20:00:48'),
(17, 'Luxury Watches', 'Today, we have an amazing collection of luxury watches which makes your mode happy. These luxury watches are available in market in very beautiful designs and colors. Everyone wants to buy watches according to the running fashion and according to their own taste. The world is progressing day by day with improvement of science although the demands for watches are not of that much quantity in past due to there are numerous alternatives available now.', 'simple', 'publish', '', 0.00, 0.00, 0.00, 0, 19, 0, '2014-08-22 20:02:12', '2014-08-22 20:02:17'),
(18, 'Luxury Watch Phone', 'The Swiss watch manufacturer, Ulysse Nardin have decided to hop on the mobile phone world and created their own luxury smartphone called the Chairman.', 'simple', 'publish', '', 0.00, 0.00, 0.00, 0, 20, 0, '2014-08-22 20:03:34', '2014-08-22 20:03:38'),
(19, 'QUARTZ HOUR DIAL CLOCK 2012 ANALOG LUXURY SPORT MEN STEEL ', 'QUARTZ HOUR DIAL CLOCK 2012 ANALOG LUXURY SPORT MEN STEEL ', 'simple', 'publish', '', 0.00, 0.00, 0.00, 0, 21, 0, '2014-08-22 20:05:03', '2014-08-22 20:05:08'),
(20, 'Luxury Watches Worldharry Winston Histoire Tourbillon', 'Luxury Watches Worldharry Winston Histoire Tourbillon', 'simple', 'publish', '', 0.00, 0.00, 0.00, 0, 22, 0, '2014-08-22 20:06:54', '2014-08-22 20:06:58'),
(21, 'V6 Men''s Sports Watch Luxury', 'V6 Men''s Sports Watch Luxury Multiple Time Zone Military Watches Business Rectangle Analog 6colors Quartz watch', 'simple', 'publish', '', 0.00, 0.00, 0.00, 0, 23, 0, '2014-08-22 20:08:24', '2014-08-22 20:08:38'),
(22, 'H3 Megawind', 'H3 Megawind H3 Megawind H3 Megawind', 'simple', 'publish', '', 0.00, 0.00, 0.00, 0, 24, 0, '2014-08-22 20:09:59', '2014-08-22 20:10:07'),
(23, 'Cartier Watch', 'cartier watch luxury fashion gear accessories watches accessory', 'simple', 'publish', '', 0.00, 0.00, 0.00, 0, 25, 0, '2014-08-22 20:11:13', '2014-08-22 20:11:29'),
(24, 'Richard Mille RM022 Aerodyne Dual Time Zone Watch', 'We really like the design of this new Richard Mille RM022 Aerodyne Dual Time Zone Watch even if it does look a bit chaotic at first glance. The case is 40 mm wide by 48 mm tall and will come in titanium, or 18 white or red gold. All versions come with alligator straps and matching buckles.\r\nWe hope you enjoyed this Richard Mille RM022 Aerodyne Dual Time Zone Watch article!', 'simple', 'publish', '', 0.00, 0.00, 0.00, 0, 26, 0, '2014-08-22 20:12:28', '2014-08-22 20:12:35'),
(25, 'HERMES', 'Hermès has added a new timepiece to its Dressage Collection – the Dressage annual calendar watch. It houses a self-winding movement by Vaucher Manufacture Fleurier. The watch features a retrograde date display, forming a 225° arc around the center of the dial, with a red crescent-tipped date indicator. ', 'simple', 'publish', '', 0.00, 0.00, 0.00, 0, 27, 0, '2014-08-22 20:13:07', '2014-08-22 20:13:13'),
(26, 'MB & F – HM3 Open Air Luxury Watch', 'HM3 from MB & F has an open air concept and is definitely a unique timepiece. The movement of the balance wheel, the date wheel and winding rotor are all out in the open for the eyes to see.\r\n\r\nThe HM3 features a Sidewinder configuration option which sets the hour and minutes cones in a line so that it is perpendicular to the arm. Another configuration called Starcruiser places the cones in-line with the arm…it is up to you how you want to orient this\r\ntruly spectacular luxury watch to show to the world.', 'simple', 'publish', '', 0.00, 0.00, 0.00, 0, 28, 0, '2014-08-22 20:13:57', '2014-08-22 20:14:02'),
(27, 'HD3 Slyde Watch, Luxury Gadget or High-End Timepiece', 'Imagine adding great technology to a high-end Swiss watch. What comes out is a masterpiece that is every watch collector’s dream. The HD3 Slyde Watch is a luxury gadget. It is a high-end timepiece. It is also a great conversation piece. If you own and wear a HD3 Slyde Watch, you can be assured that everyone will notice it. It is one of the coolest watches ever made. It surely is different, and definitely takes watchmaking to a new level. This luxury watch consists of a special, personalized touch screen display that can respond to several commands. The stunning digital display and the high-end craftsmanship offer you a timepiece that is immortal in terms of style, uniqueness and functionality.', 'simple', 'publish', '', 0.00, 0.00, 0.00, 0, 29, 0, '2014-08-22 20:14:54', '2014-08-22 20:15:04');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `permission` enum('admin','customer') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'customer',
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `permission`, `first_name`, `last_name`, `remember_token`, `created_at`, `updated_at`) VALUES
(4, 'alex', 'alex@mail.com', '$2y$10$ZM4iGIA2DjQIDnydwkDPc.wMRO5RGt6nk3bHhkKk6XwKc5WzjuXX6', 'customer', 'Alex', '', '1tfPCFy32zvvrk1BZtp8gS955I1Fe535XIYaYB2am3TAJUZP4rQlNjiQ6quZ', '2014-08-22 14:01:16', '2014-08-22 15:11:57'),
(5, 'ololo', 'ololo@mail.com', '$2y$10$XFKN8WFMFSy/fS/s9QYtxOyDUHd1kGUywEz2ErO/y9kRGoFDp2l/q', 'customer', 'Ololo', '', NULL, '2014-08-22 14:12:50', '2014-08-22 14:12:50');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
