-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 17, 2014 at 08:47 PM
-- Server version: 5.5.38-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `auction`
--

-- --------------------------------------------------------

--
-- Table structure for table `auctions`
--

CREATE TABLE IF NOT EXISTS `auctions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `products` text COLLATE utf8_unicode_ci NOT NULL,
  `start` datetime NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `auctions`
--

INSERT INTO `auctions` (`id`, `name`, `products`, `start`, `description`) VALUES
(2, '', '["7","7"]', '2014-08-17 00:29:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `bids`
--

CREATE TABLE IF NOT EXISTS `bids` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bid` float(8,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `images` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `images`, `created_at`, `updated_at`) VALUES
(6, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/5Fa3JsMGbWiJ.jpg"}', '2014-08-15 19:33:22', '2014-08-15 19:33:22'),
(7, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/G0AeQScHJzf1.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/G0AeQScHJzf1_medium.jpg"}', '2014-08-15 19:36:40', '2014-08-15 19:36:40'),
(8, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/9uScWpCuygfa.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/9uScWpCuygfa_medium.jpg"}', '2014-08-15 19:37:42', '2014-08-15 19:37:42'),
(9, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/gtL30QpINyRi.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/gtL30QpINyRi_medium.jpg"}', '2014-08-15 19:38:36', '2014-08-15 19:38:36'),
(10, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/WFidUHGfnIb5.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/WFidUHGfnIb5_medium.jpg"}', '2014-08-15 19:39:16', '2014-08-15 19:39:16'),
(11, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/Q3p2MnajsTgY.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/Q3p2MnajsTgY_medium.jpg"}', '2014-08-15 19:41:02', '2014-08-15 19:41:02'),
(12, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/Htnn4s11SRMP.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/Htnn4s11SRMP_medium.jpg"}', '2014-08-15 19:41:37', '2014-08-15 19:41:37'),
(13, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/HgfMMlpaw8yF.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/HgfMMlpaw8yF_medium.jpg"}', '2014-08-15 19:42:24', '2014-08-15 19:42:24'),
(14, '{"full":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/KUSj8UkDoq6x.jpg","medium":"http:\\/\\/localhost\\/auction\\/public\\/uploads\\/KUSj8UkDoq6x_medium.jpg"}', '2014-08-15 19:42:56', '2014-08-15 19:42:56');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_08_11_000303_create_auctions_table', 1),
('2014_08_11_000602_create_bids_table', 1),
('2014_08_11_001015_create_products_table', 1),
('2014_08_11_001210_create_users_table', 1),
('2014_08_15_174338_create_images_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('simple','auction') COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('draft','publish','hidden') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `lang` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` float(8,2) NOT NULL,
  `sale_price` float(8,2) NOT NULL,
  `opening_bid` float(8,2) NOT NULL,
  `auction_id` int(10) NOT NULL,
  `image_id` int(10) NOT NULL,
  `parent_id` int(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `type`, `status`, `lang`, `price`, `sale_price`, `opening_bid`, `auction_id`, `image_id`, `parent_id`, `created_at`, `updated_at`) VALUES
(1, 'Black Luxury Watch', 'Luxury Men Watch Black Steel wrist Watch Sport Styles top brand Men', 'auction', 'publish', '', 300.00, 0.00, 0.00, 0, 7, 0, '2014-08-14 20:46:00', '2014-08-15 21:49:18'),
(2, 'Youyoupifa', 'Youyoupifa Fashion Luxury Imitationold Quartz Wrist Watch', 'simple', 'publish', '', 570.00, 0.00, 9.00, 0, 8, 0, '2014-08-14 21:58:25', '2014-08-15 19:37:42'),
(3, 'Bossman Watch', 'Vantasy Men’s Luxury Gold Plated Stainless Steel Hand Wind Skeleton Analog Mechanical Black Leather Wrist Watch', 'simple', 'publish', '', 1300.00, 0.00, 0.00, 0, 9, 0, '2014-08-15 12:47:54', '2014-08-15 19:38:36'),
(4, 'Oblong', 'Mens Luxury Oblong Skeleton Automatic Mechanical Black Leather Wrist Watch Cool', 'simple', 'publish', '', 1050.00, 0.00, 0.00, 0, 10, 0, '2014-08-15 12:49:56', '2014-08-15 19:39:16'),
(9, 'Wind', 'Vantasy Roman Men’s Luxury Stainless Steel White Dial Skeleton Analog Hand Wind Mechanical Black Leather Wrist Watch – Wind', 'simple', 'publish', '', 1450.00, 0.00, 0.00, 0, 11, 0, '2014-08-15 19:40:26', '2014-08-15 19:41:02'),
(10, 'The Aquarium', 'Swiss watch company Angular Momentum represent its new model called “The Aquarium.” Aquarium shows a popular in Far East fish – Koi – in a muddy pond. It’s engraved in very high relief 925 silver, purple gold and Ruthenium treated surface. The eye of a koi made out from a diamond and the ground is done in black Ishime Urushi natural lacquer. The watch case is in Staybrite steel with polished and satin finished surfaces measuring 43mm wide by 16mm thick. The time is shown by single disc that spins behind the koi. These extremely beautiful luxury watches will be availiable in limited edition soon.', 'simple', 'publish', '', 1250.00, 0.00, 0.00, 0, 12, 0, '2014-08-15 19:41:33', '2014-08-15 20:41:13'),
(11, 'Key of Time', 'The “Key of Time” is impressive novelty piece from Hublot’s 2011 Masterpiece Collection. The name comes from the watch’s time-travelling ability, through 3 speed settings. For instance, you’re in a boring meeting and you can speed up the time or if it’s happy hour, you can slow it down. Of course this is just for fun, with the ingenious engineers also giving this watch the ability to return to the correct time, though its “mechanical memory”.', 'simple', 'publish', '', 1890.00, 0.00, 0.00, 0, 13, 0, '2014-08-15 19:42:16', '2014-08-15 19:42:24'),
(12, 'Opus Eleven', 'The Opus Eleven Watch is part of a numbered series of collaborative timepieces, which have gathered some of the most talented watchmakers to create for each one. This remarkable piece took over 14,400 hours to engineer alone. Using an complex system of gears and disks, the dial ‘explodes’ then reforms to display the time.', 'simple', 'publish', '', 2000.00, 0.00, 0.00, 0, 14, 0, '2014-08-15 19:42:51', '2014-08-15 19:42:56');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
